---
name: "\U0001F41B Bug report"
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

**Which Tool?**
A clear and concise description of what the bug is.

**What is the error?**
Stacktrace:

```bash
```

**fsociety info**
Run `fsociety --info` in your terminal and copy the results here.

```bash
```
