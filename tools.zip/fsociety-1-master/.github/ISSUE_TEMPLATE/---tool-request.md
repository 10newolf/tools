---
name: "⛏️ Tool request"
about: Suggest an tool for fsociety
title: ''
labels: tool
assignees: ''

---

**Link to Tool**
https://github.com/really_cool_project

**Why?**
_Why should we add this tool?_
